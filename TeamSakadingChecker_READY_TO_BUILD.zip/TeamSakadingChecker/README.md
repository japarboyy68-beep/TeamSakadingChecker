# TEAM SAKADING — WhatsApp Checker UI

Project Android siap di-build untuk Android Studio atau GitHub Actions.

## Build di Android Studio
1. Ekstrak ZIP.
2. Buka folder `TeamSakadingChecker` di Android Studio.
3. Tunggu Gradle sync selesai.
4. Pilih **Build > Build APK(s)**.
5. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Build tanpa laptop menggunakan GitHub
1. Buat repository GitHub baru.
2. Upload seluruh isi folder project ini.
3. Buka tab **Actions**.
4. Jalankan workflow **Build Team Sakading APK**.
5. Setelah selesai, buka hasil workflow dan download artifact `Team-Sakading-Checker-debug`.

## Catatan
Aplikasi ini hanya melakukan validasi format nomor dan menyediakan UI checker. WhatsApp tidak menyediakan API publik untuk memastikan status banned akun pihak ketiga. Jangan meminta atau memasukkan OTP, PIN, atau kata sandi WhatsApp.
